package com.jfsfeb.loanprocessingsystem1.dao;

import java.util.List;
import com.jfsfeb.loanprocessingsystem1.dto.LoanApplicationFormBean;
import com.jfsfeb.loanprocessingsystem1.dto.LoansBean;
import com.jfsfeb.loanprocessingsystem1.dto.TrackApplicationBean;

public interface LoanApprovalDepartmentDAO {
	public boolean ladLogin(String username, String password);

	public List<LoansBean> getAllLoanOffers();

	public List<LoanApplicationFormBean> getAllApplication();

	public boolean updateStatus(TrackApplicationBean aStatusBean);

	public List<LoanApplicationFormBean> getApplicationByLoanId(int loanId);

}
