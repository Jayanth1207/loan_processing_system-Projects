
package com.jfsfeb.loanprocessingsystem1.dao;

import java.util.List;

import com.jfsfeb.loanprocessingsystem1.dto.AdminInfoBean;
import com.jfsfeb.loanprocessingsystem1.dto.LoansBean;
import com.jfsfeb.loanprocessingsystem1.dto.TrackApplicationBean;
import com.jfsfeb.loanprocessingsystem1.repository.Database;

public class AdminDAOImpl implements AdminDAO {

	@Override
	public boolean adminLogin(String adminName,String adminPassword) {
		for (AdminInfoBean userBean : Database.ADMINBEAN) {
			if (userBean.getAdminName().equals(adminName) && userBean.getAdminPassword().equals(adminPassword)) {
				return true;
			}
		}
		return false;

	}

	@Override
	public List<LoansBean> getAllLoanOffers() {
		return Database.LOAN;

	}

	@Override
	public boolean updateLoanProgram(int loanId, float interestRate) {
		for (int i = 0; i <= Database.LOAN.size() - 1; i++) {
			LoansBean retrievedLoanOffer = Database.LOAN.get(i);
			int retrievedId = retrievedLoanOffer.getLoanId();
			if (loanId == retrievedId) {
				retrievedLoanOffer.setInterestRate(interestRate);
				return true;

			}
		}

		return false;
	}

	@Override
	public boolean createLoanPrograms(LoansBean OfferBean) {
		for (LoansBean b : Database.LOAN) {
			if (b.getLoanId() == OfferBean.getLoanId()) {
				return false;
			}
		}
		Database.LOAN.add(OfferBean);
		return true;
	}

	@Override
	public boolean deleteLoanProgram(int loanId) {
		for (int i = 0; i <= Database.LOAN.size() - 1; i++) {
			LoansBean retrievedLoanOffer = Database.LOAN.get(i);
			int retrievedId = retrievedLoanOffer.getLoanId();
			if (loanId == retrievedId) {
				Database.LOAN.remove(i);
				return true;

			}
			break;
		}
		return false;
	}

	@Override
	public List<TrackApplicationBean> getAllStatus() {
		return Database.STATUSINFO;
	}


}
