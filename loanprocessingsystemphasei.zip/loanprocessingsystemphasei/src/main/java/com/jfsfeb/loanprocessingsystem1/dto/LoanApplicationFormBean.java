package com.jfsfeb.loanprocessingsystem1.dto;

import java.io.Serializable;
import java.time.LocalDate;
import lombok.Data;

@Data
public class LoanApplicationFormBean implements Serializable {
	private int applicationId;
	private String customerName;
	private String emailId;
	private long mobile;
	private long aadharNum;
	private LocalDate dob;
	private String gender;
	private String address;
	private int loanId;
}
