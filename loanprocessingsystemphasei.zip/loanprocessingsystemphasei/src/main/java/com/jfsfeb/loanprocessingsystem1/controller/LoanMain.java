package com.jfsfeb.loanprocessingsystem1.controller;

public class LoanMain {

	public static void main(String[] args) {
		Loan.LoanOperations();
	}

}
