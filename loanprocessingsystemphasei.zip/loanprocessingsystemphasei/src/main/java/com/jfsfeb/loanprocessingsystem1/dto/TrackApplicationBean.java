package com.jfsfeb.loanprocessingsystem1.dto;

import java.io.Serializable;
import java.time.LocalDate;
import lombok.Data;

@Data
public class TrackApplicationBean implements Serializable {

	private int applicationFormId;
	private LocalDate interviewDdate;
	private String status;
}
