package com.jfsfeb.loanprocessingsystem1.services;

import java.util.List;

import com.jfsfeb.loanprocessingsystem1.dto.AdminInfoBean;
import com.jfsfeb.loanprocessingsystem1.dto.LoansBean;
import com.jfsfeb.loanprocessingsystem1.dto.TrackApplicationBean;

public interface AdminServices {

	public boolean adminLogin(String adminName, String adminPassword);

	public List<LoansBean> getAllLoanOffers();

	public boolean updateLoanProgram(int loanId, float interestRate);

	public boolean createLoanPrograms(LoansBean OfferBean);

	public boolean deleteLoanProgram(int loanId);

	public List<TrackApplicationBean> getAllStatus();
}
