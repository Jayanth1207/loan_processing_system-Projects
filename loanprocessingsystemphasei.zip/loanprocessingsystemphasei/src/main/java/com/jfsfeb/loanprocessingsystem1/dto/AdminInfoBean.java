package com.jfsfeb.loanprocessingsystem1.dto;

import java.io.Serializable;
import lombok.Data;
import lombok.ToString;

@Data
public class AdminInfoBean implements Serializable {

	private int adminId;
	private String adminName;
	private String role;
	@ToString.Exclude
	private String adminPassword;
}
