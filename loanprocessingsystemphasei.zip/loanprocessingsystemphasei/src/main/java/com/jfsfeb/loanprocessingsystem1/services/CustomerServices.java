package com.jfsfeb.loanprocessingsystem1.services;

import java.util.List;

import com.jfsfeb.loanprocessingsystem1.dto.LoanApplicationFormBean;
import com.jfsfeb.loanprocessingsystem1.dto.LoansBean;
import com.jfsfeb.loanprocessingsystem1.dto.TrackApplicationBean;

public interface CustomerServices {
	public boolean registerCustomer(LoanApplicationFormBean formBean);

	public TrackApplicationBean getAppStatusById(int appId);

	public List<LoansBean> getAllLoanOffers();
}
