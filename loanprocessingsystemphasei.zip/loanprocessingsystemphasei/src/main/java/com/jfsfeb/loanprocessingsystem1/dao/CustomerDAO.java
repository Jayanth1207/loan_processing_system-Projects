package com.jfsfeb.loanprocessingsystem1.dao;

import java.util.List;

import com.jfsfeb.loanprocessingsystem1.dto.LoanApplicationFormBean;
import com.jfsfeb.loanprocessingsystem1.dto.LoansBean;
import com.jfsfeb.loanprocessingsystem1.dto.TrackApplicationBean;

public interface CustomerDAO {
	public boolean registerCustomer(LoanApplicationFormBean formBean);

	public TrackApplicationBean getAppStatusById(int appId);

	public  List<LoansBean> getAllLoanOffers();
}
