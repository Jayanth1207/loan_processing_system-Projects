package com.jfsfeb.loanprocessingsystem1.dao;

import java.util.List;

import com.jfsfeb.loanprocessingsystem1.dto.LoanApplicationFormBean;
import com.jfsfeb.loanprocessingsystem1.dto.LoansBean;
import com.jfsfeb.loanprocessingsystem1.dto.TrackApplicationBean;
import com.jfsfeb.loanprocessingsystem1.repository.Database;

public class CustomerDAOImpl implements CustomerDAO {

	@Override
	public boolean registerCustomer(LoanApplicationFormBean formBean) {
		for (LoanApplicationFormBean appBean : Database.APPFORM) {
			if (appBean.getApplicationId() == formBean.getApplicationId()) {
				return false;
			}
		}
		Database.APPFORM.add(formBean);
		return true;

	}

	@Override
	public TrackApplicationBean getAppStatusById(int appId) {
		for (TrackApplicationBean statusBean : Database.STATUSINFO) {
			if (appId == statusBean.getApplicationFormId()) {
				return statusBean;
			}

		}

		return null;
	}

	@Override
	public List<LoansBean> getAllLoanOffers() {
		return Database.LOAN;
	}

}
