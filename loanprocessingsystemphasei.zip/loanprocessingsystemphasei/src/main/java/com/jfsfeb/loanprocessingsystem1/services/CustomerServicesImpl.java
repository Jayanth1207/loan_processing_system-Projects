package com.jfsfeb.loanprocessingsystem1.services;

import java.util.List;

import com.jfsfeb.loanprocessingsystem1.dao.CustomerDAO;
import com.jfsfeb.loanprocessingsystem1.dto.LoanApplicationFormBean;
import com.jfsfeb.loanprocessingsystem1.dto.LoansBean;
import com.jfsfeb.loanprocessingsystem1.dto.TrackApplicationBean;
import com.jfsfeb.loanprocessingsystem1.exception.LoanException;
import com.jfsfeb.loanprocessingsystem1.factory.UserFactory;
import com.jfsfeb.loanprocessingsystem1.validations.Validations;

public class CustomerServicesImpl implements CustomerServices {

	CustomerDAO dao = UserFactory.getCustomerDAOImplInstance();
	Validations val = UserFactory.getValidationInstance();

	@Override
	public boolean registerCustomer(LoanApplicationFormBean formBean) {
		if (val.validatedName(formBean.getCustomerName())) {
			if (val.validateEmail(formBean.getEmailId())) {
				if (val.validatedMobile(formBean.getMobile())) {
					if (val.validatedAddress(formBean.getAddress())) {
						if (val.validatedAadharId(formBean.getAadharNum())) {
							return dao.registerCustomer(formBean);
						}
					}
				}
			}
		}
		throw new LoanException("Invalid");
	}

	@Override
	public TrackApplicationBean getAppStatusById(int appId) {
		if (val.validatedId(appId)) {
			return dao.getAppStatusById(appId);
		}
		throw new LoanException("No stataus found..");
	}

	@Override
	public List<LoansBean> getAllLoanOffers() {

		return dao.getAllLoanOffers();
	}

}
