package com.jfsfeb.loanprocessingsystem1.dao;

import java.util.List;
import com.jfsfeb.loanprocessingsystem1.dto.LoansBean;
import com.jfsfeb.loanprocessingsystem1.dto.TrackApplicationBean;

public interface AdminDAO {
	public boolean adminLogin(String adminName, String adminpassword);

	public List<LoansBean> getAllLoanOffers();

	public  boolean updateLoanProgram(int loanId, float interestRate);

	public boolean createLoanPrograms(LoansBean OfferBean);

	public boolean deleteLoanProgram(int loanId);

	public List<TrackApplicationBean> getAllStatus();

}
