package com.jfsfeb.loanprocessingsystem1.repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.jfsfeb.loanprocessingsystem1.dto.AdminInfoBean;
import com.jfsfeb.loanprocessingsystem1.dto.LoanApplicationFormBean;
import com.jfsfeb.loanprocessingsystem1.dto.LoanApprovalDepartmentBean;
import com.jfsfeb.loanprocessingsystem1.dto.LoansBean;
import com.jfsfeb.loanprocessingsystem1.dto.TrackApplicationBean;

public class Database {

	public static final List<LoanApprovalDepartmentBean> LAD = new ArrayList<LoanApprovalDepartmentBean>();
	public static final List<AdminInfoBean> ADMINBEAN = new ArrayList<AdminInfoBean>();
	public static final List<LoansBean> LOAN = new ArrayList<LoansBean>();
	public static final List<LoanApplicationFormBean> APPFORM = new ArrayList<LoanApplicationFormBean>();
	public static final List<TrackApplicationBean> STATUSINFO = new ArrayList<TrackApplicationBean>();

	public static void addToDB() {
//===============================================================Admin Info Bean=====================================================
		AdminInfoBean adminInfo = new AdminInfoBean();
		adminInfo.setAdminId(1);
		adminInfo.setAdminName("Jayanth");
		adminInfo.setAdminPassword("Nani123@");
		ADMINBEAN.add(adminInfo);
		
		AdminInfoBean adminInfo1 = new AdminInfoBean();
		adminInfo1.setAdminId(1);
		adminInfo1.setAdminName("Nani");
		adminInfo1.setAdminPassword("Nani123@");
		ADMINBEAN.add(adminInfo1);
		
		AdminInfoBean adminInfo2 = new AdminInfoBean();
		adminInfo2.setAdminId(1);
		adminInfo2.setAdminName("Laila");
		adminInfo2.setAdminPassword("Nani123@");
		ADMINBEAN.add(adminInfo2);
		
		
//=========================================================Loan approval department bean=============================================	
		LoanApprovalDepartmentBean lad = new LoanApprovalDepartmentBean();
		lad.setUserId(2);
		lad.setUsername("Nani");
		lad.setRole("lad");
		lad.setPassword("121");
		LAD.add(lad);
	
//===========================================================Loan application Form bean==================================================
		LoanApplicationFormBean laf = new LoanApplicationFormBean();
		laf.setApplicationId(10);
		laf.setCustomerName("Baji");
		laf.setEmailId("Baji@gmail.com");
		laf.setMobile(Long.parseLong("8008219089"));
		laf.setAadharNum(1245723832);
		laf.setDob(LocalDate.of(2020, 02, 22));
		laf.setGender("male");
		laf.setLoanId(12);
		APPFORM.add(laf);
		
		LoanApplicationFormBean laf2 = new LoanApplicationFormBean();
		laf2.setApplicationId(21);
		laf2.setCustomerName("Nani");
		laf2.setEmailId("Nani@gmail.com");
		laf2.setMobile(Long.parseLong("8008219089"));
		laf2.setAadharNum(1245723832);
		laf2.setDob(LocalDate.of(2020, 02, 22));
		laf2.setGender("male");
		laf2.setLoanId(23);
		APPFORM.add(laf2);
		
		LoanApplicationFormBean laf3 = new LoanApplicationFormBean();
		laf3.setApplicationId(43);
		laf3.setCustomerName("ManiHarika");
		laf3.setEmailId("ManiHarika@gmail.com");
		laf3.setMobile(Long.parseLong("8008219089"));
		laf3.setAadharNum(1245723832);
		laf3.setDob(LocalDate.of(2020, 02, 22));
		laf3.setGender("Female");
		laf3.setLoanId(44);
		APPFORM.add(laf3);
		
		LoanApplicationFormBean laf4 = new LoanApplicationFormBean();
		laf4.setApplicationId(43);
		laf4.setCustomerName("Anusha");
		laf4.setEmailId("Anusha@gmail.com");
		laf4.setMobile(Long.parseLong("8008219089"));
		laf4.setAadharNum(1245723832);
		laf4.setDob(LocalDate.of(2020, 02, 22));
		laf4.setGender("Female");
		laf4.setLoanId(55);
		APPFORM.add(laf4);
//=====================================================================LoansBean=====================================================
		LoansBean loansbean = new LoansBean();
		loansbean.setLoanId(10);
		loansbean.setLoanType("Home");
		loansbean.setInterestRate(11);
		loansbean.setLoanPeriod(2);
		LOAN.add(loansbean);
		
		LoansBean loansbean1 = new LoansBean();
		loansbean1.setLoanId(12);
		loansbean1.setLoanType("Bike Loan");
		loansbean1.setInterestRate(10);
		loansbean1.setLoanPeriod(1);
		LOAN.add(loansbean1);
		
		LoansBean loansbean2 = new LoansBean();
		loansbean2.setLoanId(22);
		loansbean2.setLoanType("Car Loan");
		loansbean2.setInterestRate(5);
		loansbean2.setLoanPeriod(2);
		LOAN.add(loansbean2);
		
		LoansBean loansbean3 = new LoansBean();
		loansbean3.setLoanId(14);
		loansbean3.setLoanType("Educational Loan");
		loansbean3.setInterestRate(1);
		loansbean3.setLoanPeriod(2);
		LOAN.add(loansbean3);
		
//=============================================================Track Application Bean==================================================
		TrackApplicationBean tab = new TrackApplicationBean();
		tab.setApplicationFormId(12);
		tab.setInterviewDdate(LocalDate.of(2020, 06, 28));
		tab.setStatus("Approved");
		STATUSINFO.add(tab);
		
		TrackApplicationBean tab1 = new TrackApplicationBean();
		tab.setApplicationFormId(21);
		tab.setInterviewDdate(LocalDate.of(2020, 06, 30));
		tab.setStatus("Approved");
		STATUSINFO.add(tab1);

	}

}
