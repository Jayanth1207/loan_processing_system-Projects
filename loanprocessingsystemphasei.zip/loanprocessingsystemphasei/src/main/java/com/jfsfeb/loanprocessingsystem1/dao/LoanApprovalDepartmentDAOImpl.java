package com.jfsfeb.loanprocessingsystem1.dao;

import java.util.ArrayList;
import java.util.List;
import com.jfsfeb.loanprocessingsystem1.dto.LoanApplicationFormBean;
import com.jfsfeb.loanprocessingsystem1.dto.LoanApprovalDepartmentBean;
import com.jfsfeb.loanprocessingsystem1.dto.LoansBean;
import com.jfsfeb.loanprocessingsystem1.dto.TrackApplicationBean;
import com.jfsfeb.loanprocessingsystem1.exception.LoanException;
import com.jfsfeb.loanprocessingsystem1.repository.Database;

public class LoanApprovalDepartmentDAOImpl implements LoanApprovalDepartmentDAO {

	@Override
	public boolean ladLogin(String username, String password) {
		for (LoanApprovalDepartmentBean userBean : Database.LAD) {
			if (userBean.getUsername().equals(username) && userBean.getPassword().equals(password)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public List<LoansBean> getAllLoanOffers() {
		return Database.LOAN;
	}

	@Override
	public List<LoanApplicationFormBean> getAllApplication() {
		return Database.APPFORM;
	}

	@Override
	public boolean updateStatus(TrackApplicationBean aStatusBean) {
		boolean updateStatus = false;
		for (TrackApplicationBean appBean : Database.STATUSINFO) {
			if (appBean.getApplicationFormId() == aStatusBean.getApplicationFormId()) {
				return false;
			}
		}
		Database.STATUSINFO.add(aStatusBean);
		return true;
	}

	@Override
	public List<LoanApplicationFormBean> getApplicationByLoanId(int loanId) {
		List<LoanApplicationFormBean> getList = new ArrayList<LoanApplicationFormBean>();
		for (int i = 0; i <= Database.APPFORM.size() - 1; i++) {

			LoanApplicationFormBean retrievedApplication = Database.APPFORM.get(i);
			int retrievedLoanId = retrievedApplication.getLoanId();

			if (loanId == retrievedLoanId) {

				getList.add(retrievedApplication);
				return getList;

			}
		}
		throw new LoanException("Given application id not found..!");
	}

}
