package com.jfsfeb.loanprocessingsystem1.services;

import java.util.List;
import com.jfsfeb.loanprocessingsystem1.dao.AdminDAO;
import com.jfsfeb.loanprocessingsystem1.dto.LoansBean;
import com.jfsfeb.loanprocessingsystem1.dto.TrackApplicationBean;
import com.jfsfeb.loanprocessingsystem1.exception.LoanException;
import com.jfsfeb.loanprocessingsystem1.factory.UserFactory;
import com.jfsfeb.loanprocessingsystem1.validations.Validations;

public class AdminServicesImpl implements AdminServices {
	AdminDAO dao = UserFactory.getAdminDAOImplInstance();
	Validations val = UserFactory.getValidationInstance();

	@Override
	public boolean adminLogin(String adminName, String adminPassword) {
		if (adminName != null && adminPassword != null) {
			if (val.validatedadminName(adminName)) {
				if (val.validatedadminPassword(adminPassword)) {
					return dao.adminLogin(adminName, adminPassword);
				}
			}
		}
		return false;
	}

	@Override
	public List<LoansBean> getAllLoanOffers() {

		return dao.getAllLoanOffers();
	}

	@Override
	public boolean updateLoanProgram(int loanId, float interestRate) {
		if (val.validatedId(loanId)) {
			if (val.validatedIntrestRate(interestRate)) {
				return dao.updateLoanProgram(loanId, interestRate);
			}
		}
		throw new LoanException("invalid values");
	}

	@Override
	public boolean createLoanPrograms(LoansBean OfferBean) {
		if (val.validatedId(OfferBean.getLoanId())) {
			if (val.validateLoanType(OfferBean.getLoanType())) {
				if (val.validatedIntrestRate(OfferBean.getInterestRate())) {
					if (val.validatedPeriod(OfferBean.getLoanPeriod())) {
						return dao.createLoanPrograms(OfferBean);
					}
				}
			}
		}
		throw new LoanException("invalid values");

	}

	@Override
	public boolean deleteLoanProgram(int loanId) {
		if (val.validatedId(loanId)) {
			return dao.deleteLoanProgram(loanId);
		}
		throw new LoanException("inavild loan id");
	}

	@Override
	public List<TrackApplicationBean> getAllStatus() {

		return dao.getAllStatus();
	}

}
