package com.jfsfeb.loanprocessingsystem1.factory;

import com.jfsfeb.loanprocessingsystem1.dao.AdminDAO;
import com.jfsfeb.loanprocessingsystem1.dao.AdminDAOImpl;
import com.jfsfeb.loanprocessingsystem1.dao.CustomerDAO;
import com.jfsfeb.loanprocessingsystem1.dao.CustomerDAOImpl;
import com.jfsfeb.loanprocessingsystem1.dao.LoanApprovalDepartmentDAO;
import com.jfsfeb.loanprocessingsystem1.dao.LoanApprovalDepartmentDAOImpl;
import com.jfsfeb.loanprocessingsystem1.services.AdminServices;
import com.jfsfeb.loanprocessingsystem1.services.AdminServicesImpl;
import com.jfsfeb.loanprocessingsystem1.services.CustomerServices;
import com.jfsfeb.loanprocessingsystem1.services.CustomerServicesImpl;
import com.jfsfeb.loanprocessingsystem1.services.LoanApprovalDepartmentServices;
import com.jfsfeb.loanprocessingsystem1.services.LoanApprovalDepartmentServicesImpl;
import com.jfsfeb.loanprocessingsystem1.validations.Validations;
import com.jfsfeb.loanprocessingsystem1.validations.ValidationsImpl;

public class UserFactory {
	private UserFactory() {
	}

	public static AdminDAO getAdminDAOImplInstance() {
		AdminDAO dao = new AdminDAOImpl();
		return dao;
	}

	public static CustomerDAO getCustomerDAOImplInstance() {
		CustomerDAO customerdao = new CustomerDAOImpl();
		return customerdao;
	}

	public static LoanApprovalDepartmentDAO getLoanApprovalDepartmentDAOInstance() {
		LoanApprovalDepartmentDAO loandao = new LoanApprovalDepartmentDAOImpl();
		return loandao;
	}

	public static AdminServices getAdminServicesImplInstance() {
		AdminServices adminServices = new AdminServicesImpl();
		return adminServices;
	}

	public static CustomerServices getCustomerServicesImplInstance() {
		CustomerServices custServices = new CustomerServicesImpl();
		return custServices;
	}

	public static LoanApprovalDepartmentServices getLoanApprovalDepartmentServicesInstance() {
		LoanApprovalDepartmentServices ladServices = new LoanApprovalDepartmentServicesImpl();
		return ladServices;
	}
	
	public static Validations getValidationInstance() {
		Validations val = new ValidationsImpl();
		return val;
	}
  
	
}
