package com.jfsfeb.loanprocessingsystem1.controller;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import com.jfsfeb.loanprocessingsystem1.dao.AdminDAO;
import com.jfsfeb.loanprocessingsystem1.dao.LoanApprovalDepartmentDAO;
import com.jfsfeb.loanprocessingsystem1.dto.LoanApplicationFormBean;
import com.jfsfeb.loanprocessingsystem1.dto.LoansBean;
import com.jfsfeb.loanprocessingsystem1.dto.TrackApplicationBean;
import com.jfsfeb.loanprocessingsystem1.exception.LoanException;
import com.jfsfeb.loanprocessingsystem1.factory.UserFactory;
import com.jfsfeb.loanprocessingsystem1.repository.Database;
import com.jfsfeb.loanprocessingsystem1.services.AdminServices;
import com.jfsfeb.loanprocessingsystem1.services.AdminServicesImpl;
import com.jfsfeb.loanprocessingsystem1.services.CustomerServices;
import com.jfsfeb.loanprocessingsystem1.services.CustomerServicesImpl;
import com.jfsfeb.loanprocessingsystem1.services.LoanApprovalDepartmentServices;
import com.jfsfeb.loanprocessingsystem1.services.LoanApprovalDepartmentServicesImpl;
import lombok.extern.log4j.Log4j;

@Log4j
public class Loan {
	public static void LoanOperations() {

		Database.addToDB();
		boolean flag = false;
		String username = null;
		String password = null;
		String adminName = null;
		String adminPassword = null;
		int loanId = 0;
		String loanType = null;
		float interestRate = 0;
		int loanPeriod = 0;
		int appId = 0;
		String customerName = null;
		String emailId = null;
		long mobile = 0;
		String address = null;
		long aadharNum = 0;
		LocalDate dob = null;
		String gender = null;
		int loanId1 = 0;

		int statusAppId = 0;
		String status = null;
		LocalDate interviewDate = null;

		// SERVICES
		AdminServices service = new AdminServicesImpl();
		LoanApprovalDepartmentServices memService = new LoanApprovalDepartmentServicesImpl();
		CustomerServices custService = new CustomerServicesImpl();

		// BEAN
		LoansBean loanBean = null;
		TrackApplicationBean sBean = null;
		// VALIDATIONS
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);

		do {
			try {
				log.info("==============================Welcome"
						+ " to loan process management system==============================");
				log.info("Press 1 to Admin/Loan Approval Department Page....!");
				log.info("Press 2 to Customer Page...!");
				log.info("================================================================="
						+ "===========================================================");
				int i = scanner.nextInt();
				switch (i) {
				case 1:
					do {
						try {
							log.info("Press 1 to Admin Login");
							log.info("Press 2 to go to Loan Approval Department");
							log.info("Press 3 to exit");

							int choice = scanner.nextInt();
							switch (choice) {

							case 1:
								AdminDAO dao = UserFactory.getAdminDAOImplInstance();
								log.info("Enter Admin Name :");
								adminName = scanner.next();
								log.info("Enter admin Password :");
								adminPassword = scanner.next();
								boolean result = service.adminLogin(adminName, adminPassword);
								if (result == true) {
									do {
										try {

											log.info("Select any from below.");
											log.info("Press 1 to add loans.");
											log.info("Press 2 to update loan offers.");
											log.info("Press 3 to delete loan offers.");
											log.info("Press 4 view all loans.");
											log.info("Press 5 to check status.");
											log.info("Press 6 to for main.");
											int choice1 = scanner.nextInt();
											switch (choice1) {
											case 1:
//											   Loan Id
												try {
													log.info("Enter loanId :");
													loanId = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												// Loan type
												log.info("Enter Type of the loan :");
												loanType = scanner.next();

												// INTEREST RATE
												try {
													log.info("Please Enter intrest Rate :");
													interestRate = scanner.nextFloat();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												// LOAN PERIOD
												try {
													log.info("Enter loan Period :");
													loanPeriod = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												loanBean = new LoansBean();
												loanBean.setLoanId(loanId);
												loanBean.setLoanType(loanType);
												loanBean.setInterestRate(interestRate);
												loanBean.setLoanPeriod(loanPeriod);

												boolean createStatus = service.createLoanPrograms(loanBean);
												if (createStatus) {
													log.info("Loan programs are added successfully...!");
												} else {
													log.info("Loan program already exist..!");
												}
												break;

											case 2:
												// ENTER LOAN ID
												try {
													log.info("Please enter loan Id to update interest rate:");
													loanId = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}
												// ENTER INTEREST RATE
												try {
													log.info("Please Enter intrest rate :");
													interestRate = scanner.nextFloat();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}

												try {

													boolean updateLoanStatus = service.updateLoanProgram(loanId,
															interestRate);
													if (updateLoanStatus) {
														log.info("loan program updated");
													} else {
														System.err.println("loan program not updated");
													}

												} catch (Exception e) {
													System.err.println("loan programs is not availble");
												}

												break;

											case 3:
												// LOAN ID DELETION
												try {
													log.info("Please Enter the loan Id to be deleted :");
													loanId = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}
												boolean remove = service.deleteLoanProgram(loanId);

												if (remove) {
													log.info("--Loan program is removed succesfully--");
												} else {
													System.err.println("----Loan program is not removed ---");
												}
												break;
											case 4:
												log.info("view all loan offers");
												List<LoansBean> loanOfferBeans = service.getAllLoanOffers();
												log.info("------------------------------------------------------"
														+ "--------");
												log.info(String.format("%-13s %-15s %-13s %-15s", "Loan_Id",
														"Loan_Type", "Interest_Rate", "Loan_Period"));
												for (LoansBean loOfferBean : loanOfferBeans) {

													if (loOfferBean != null) {

														log.info(String.format("%-13s %-15s %-13s %-15s",
																loOfferBean.getLoanId(), loOfferBean.getLoanType(),
																loOfferBean.getInterestRate(),
																loOfferBean.getLoanPeriod()));
													} else {
														log.info("loan programs are  not present");
													}
												}
												log.info("------------------------------------------------------"
														+ "----------");

												break;
											case 5:
												log.info("checking application status...");

												List<TrackApplicationBean> statusList = service.getAllStatus();
												log.info("------------------------------------------------------"
														+ "--");
												log.info(String.format("%-13s %-15s %-13s", "Application_Id",
														"Interview_Date", "Status"));
												for (TrackApplicationBean applicationStatusBean : statusList) {
													if (applicationStatusBean != null) {
														log.info(String.format("%-13s %-15s %-13s",
																applicationStatusBean.getApplicationFormId(),
																applicationStatusBean.getInterviewDdate(),
																applicationStatusBean.getStatus()));
													} else {
														log.info("Application status is not been tracked .");
													}
												}
												log.info("------------------------------------------------------"
														+ "---");
												break;

											case 6:
												LoanOperations();
											default:
												System.err.println("Invalid Choice!!please select between 1-6");
												break;
											}
										} catch (InputMismatchException ex) {
											System.err.println("Incorrect entry. Please enter valid choice");
											scanner.nextLine();
										}

									} while (true);
								} else {
									log.info("Invalid credentials");
								}
//								log.info("----------Welcome Admin-----------");

							case 2: // Loan Approval Department login
								LoanApprovalDepartmentDAO dao1 = UserFactory.getLoanApprovalDepartmentDAOInstance();
								log.info("Enter Username :");
								username = scanner.next();
								log.info("Enter Password :");
								password = scanner.next();
								boolean result1 = memService.ladLogin(username, password);
								if (result1 == true) {
									do {
										try {
											log.info("Select ur choice from below");
											log.info("Select 1 to view all loans offers...");
											log.info("Select 2 to view all applications..");
											log.info("Select 3 to update application status..");
											log.info("Select 4 to get all application based on loan id..");
											log.info("Select 5 to go to main...");
											int choice2 = scanner.nextInt();
											switch (choice2) {
											case 1:
												log.info("view all loan offers");
												List<LoansBean> loanOfferBeans = memService.getAllLoanOffers();
												log.info("------------------------------------------------------"
														+ "------");

												log.info(String.format("%-13s %-15s %-13s %-15s", "Loan_Id",
														"Loan_Type", "Interest_Rate", "Loan_Period"));
												for (LoansBean loOfferBean : loanOfferBeans) {
													if (loOfferBean != null) {
														log.info(String.format("%-13s %-15s %-13s %-15s",
																loOfferBean.getLoanId(), loOfferBean.getLoanType(),
																loOfferBean.getInterestRate(),
																loOfferBean.getLoanPeriod()));
													} else {
														System.err.println("loan programs are not available");
													}
												}
												log.info("------------------------------------------------------"
														+ "------");
												break;
											case 2:

												List<LoanApplicationFormBean> aFormBeans = memService
														.getAllApplication();
												log.info(
														"------------------------------------------------------------------------------------------"
																+ "---------------------------------------------------");
												log.info(String.format(
														"%-13s %-16s %-13s %-13s %-20s %-14s %-17s %-15s %-15s ",
														"Application_Id", "CustomerName", "MobileNumber", "EmailId",
														"AadharNumber", "Address", "DOB", "Gender", "Loan_Id"));
												log.info(
														"------------------------------------------------------------------------------------------"
																+ "---------------------------------------------------");

												for (LoanApplicationFormBean applicationFormBean : aFormBeans) {
													if (aFormBeans != null) {
														log.info(String.format(
																"%-13s %-15s %-16s %-1s %-16s %-14s %-18s %-18s %-20s ",
																applicationFormBean.getApplicationId(),
																applicationFormBean.getCustomerName(),
																applicationFormBean.getMobile(),
																applicationFormBean.getEmailId(),
																applicationFormBean.getAadharNum(),
																applicationFormBean.getAddress(),
																applicationFormBean.getDob(),
																applicationFormBean.getGender(),
																applicationFormBean.getLoanId()));

													}
												}
												log.info("------------------------------------------------------"
														+ "-------------------------------------------------------------------------------------");
												break;
											case 3:
												// APPLICATION ID
												try {
													sBean = new TrackApplicationBean();
													log.info("Enter the Application Id  :");
													statusAppId = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}
												do {
													try {
														log.info("Enter interview date: ");
														interviewDate = LocalDate.parse(scanner.next());
														flag = true;
													} catch (DateTimeParseException e) {
														flag = false;
														System.err.println("invalid date format...");
													} catch (LoanException e) {
														flag = false;
														System.err.println(e.getMessage());
													}
												} while (!flag);
												do {
													try {
														log.info("Enter status: ");
														status = scanner.next();
														flag = true;
													} catch (LoanException e) {
														flag = false;
														System.err.println(e.getMessage());
													} catch (InputMismatchException e) {
														flag = false;
														log.info("inavlid Application status...");
													}
												} while (!flag);
												try {
													sBean.setApplicationFormId(statusAppId);
													sBean.setInterviewDdate(interviewDate);
													sBean.setStatus(status);
													boolean updateStatus = memService.updateStatus(sBean);
													if (updateStatus) {
														log.info("Updated succesfully..!");
													} else {
														System.err.println("Status is not updated..");
													}

												} catch (Exception e) {
													e.getMessage();
												}

												break;
											case 4:
												// LOAN ID
												try {
													log.info("Enter loan Id...");
													loanId = scanner.nextInt();
												} catch (InputMismatchException e) {
													scanner.nextLine();
												}
												try {
													List<LoanApplicationFormBean> lFormBeans2 = memService
															.getApplicationByLoanId(loanId);

													log.info("------------------------------------------------------"
															+ "-------------------------------------------------------------------------------------");

													log.info(String.format(
															"%-13s %-15s %-13s %-13s %-20s %-14s %-17s %-15s %-15s ",
															"Application_Id", "CustomerName", "MobileNumber", "EmailId",
															"AadharNumber", "Address", "DOB", "Gender", "Loan_Id"));

													for (LoanApplicationFormBean applicationFormBean : lFormBeans2) {
														if (applicationFormBean != null) {
															log.info(String.format(
																	"%-13s %-15s %-16s %-1s %-16s %-14s %-18s %-18s %-20s ",
																	applicationFormBean.getApplicationId(),
																	applicationFormBean.getCustomerName(),
																	applicationFormBean.getMobile(),
																	applicationFormBean.getEmailId(),
																	applicationFormBean.getAadharNum(),
																	applicationFormBean.getAddress(),
																	applicationFormBean.getDob(),
																	applicationFormBean.getGender(),
																	applicationFormBean.getLoanId()));

														}
													}
													log.info("------------------------------------------------------"
															+ "-----------------------------------------------------------"
															+ "--------------------------");

												} catch (Exception e) {
													System.err.println("Application details not found..!");
												}

												break;
											case 5:
												LoanOperations();
											default:
												System.err.println("Invalid choice..!");
												break;
											}
										} catch (InputMismatchException ex) {
											log.info("Incorrect entry. Please enter valid choice");
											scanner.nextLine();
										}
									} while (true);
								} else {
									log.info("Invalid login details");
								}

							case 3:
								LoanOperations();
								break;
							default:

								System.err.println("Invalid Choice");
								break;
							}
						} catch (InputMismatchException ex) {
							System.err.println("Incorrect entry. Please enter only choices");
							scanner.nextLine();
						}
					} while (true);

				case 2:
					// ***customer operation****//
					System.out.println("----------Welcome to customer page-----------");
					do {
						try {
							System.out.println("Enter 1 to view all loan offers..");
							System.out.println("Enter 2  to fill application form...");
							System.out.println("Enter 3 to check application status..");
							System.out.println("Enter 4 to main...");
							int choice = scanner.nextInt();
							switch (choice) {
							case 1:
								System.out.println("view all loan offers");
								List<LoansBean> loanOfferBeans = custService.getAllLoanOffers();
								System.out
										.println("------------------------------------------------------" + "-------");
								System.out.println(String.format("%-13s %-15s %-13s %-15s", "LoanId", "LoanType",
										"InterestRate", "LoanPeriod"));
								for (LoansBean loOfferBean : loanOfferBeans) {
									if (loOfferBean != null) {
										System.out.println(String.format("%-13s %-15s %-13s %-15s",
												loOfferBean.getLoanId(), loOfferBean.getLoanType(),
												loOfferBean.getInterestRate(), loOfferBean.getLoanPeriod()));
									} else {
										System.out.println("loan programs are  not present");
									}
								}
								System.out
										.println("------------------------------------------------------" + "-------");

								break;

							case 2:
								System.out.println("Please Fill the details in form..");
								LoanApplicationFormBean formBean = new LoanApplicationFormBean();// modified
								try {
									appId = (int) (Math.random() * 100);
									System.out.println("Your application id: " + appId);
								} catch (LoanException e) {
									System.err.println(e.getMessage());
								}
								System.out.println("Enter your name:");
								customerName = scanner.next();
								System.out.println("Enter your email:");
								emailId = scanner.next();

								try {
									System.out.println("Enter your Mobile:");
									mobile = scanner.nextLong();
								} catch (InputMismatchException e) {
									scanner.nextLine();
								}
								System.out.println("Enter your Address:");
								address = scanner.next();

								try {
									System.out.println("Enter your Aadhar Number");
									aadharNum = scanner.nextLong();
								} catch (InputMismatchException e) {
									scanner.nextLine();
								}
									do {
										try {
											System.out.println("Enter your dob:");
											dob = LocalDate.parse(scanner.next());
											formBean.setDob(dob);
											System.out.println(formBean.getDob());

											flag = true;

										} catch (DateTimeParseException e1) {
											flag = false;
											System.err.println("Please provide date in this format(yyyy-mm-dd)");
											scanner.nextLine();
										} catch (LoanException e1) {
											flag = false;
											System.err.println(e1.getMessage());
										}

									} while (!flag);

									System.out.println("Enter your gender:");
									gender = scanner.next();

									try {
										System.out.println("Enter  loan Id");
										loanId1 = scanner.nextInt();
									} catch (InputMismatchException e1) {
										scanner.nextLine();
									}

									formBean.setApplicationId(appId);
									formBean.setCustomerName(customerName);
									formBean.setEmailId(emailId);
									formBean.setMobile(mobile);
									formBean.setAddress(address);
									formBean.setAadharNum(aadharNum);
									formBean.setDob(dob);
									formBean.setGender(gender);
									formBean.setLoanId(loanId1);

									boolean appStatus = custService.registerCustomer(formBean);
									System.out.println(formBean.getApplicationId());
									if (appStatus) {
										System.out.println("Submitted application successfully....!");
									} else {
										System.out.println("Details already exists.!");
								}
								break;
							case 3:
								System.out.println("Enter your Application id to check status.");
									try {
										appId = scanner.nextInt();
									} catch (InputMismatchException e) {
										scanner.nextLine();
									} 
									
								try {
									TrackApplicationBean check = custService.getAppStatusById(appId);
									if (check.getApplicationFormId() == appId) {
										System.out.println(
												"----------------------------------------" + "--------------------");
										System.out.println(String.format("%-15s %-18s %-13s", "Application Id",
												"Interview Date", "Status"));
										if (check!= null) {
											System.out.println(
													String.format("%-15s %-17s %-15s", check.getApplicationFormId(),
															check.getInterviewDdate(), check.getStatus()));

											System.out.println("--------------------------------------------"
													+ "-----------------");

										} else
											System.out.println("No");
									}
								} catch (Exception e) {
									System.err.println("Application not found..");
								}
								break;
							case 4:
								LoanOperations();
								break;
							default:

								System.err.println("Invalid Choice");
								break;
							}
						} catch (InputMismatchException ex) {
							System.err.println("Incorrect entry. Please select only from above choices");
							scanner.nextLine();
						}

					} while (true);

				case 3:
					System.err.println("Please enter a valid chioce between 1-2");
					LoanOperations();
					break;
				default:
					System.err.println("Please enter a valid chioce between 1-2");

				}
			} catch (InputMismatchException ex) {
				System.err.println("Incorrect entry. Please enter valid choice");
				scanner.nextLine();
			}

		} while (true);
	}// End of method

}// End of Class
