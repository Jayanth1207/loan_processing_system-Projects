package com.jfsfeb.loanprocessingsystem1.dto;

import java.io.Serializable;
import lombok.Data;

@Data
public class LoansBean implements Serializable {
	private int loanId;
	private String loanType;
	private float interestRate;
	private int loanPeriod;

}
