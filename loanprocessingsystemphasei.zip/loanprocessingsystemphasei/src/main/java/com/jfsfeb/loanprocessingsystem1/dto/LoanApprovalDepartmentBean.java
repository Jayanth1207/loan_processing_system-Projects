package com.jfsfeb.loanprocessingsystem1.dto;

import java.io.Serializable;
import lombok.Data;
import lombok.ToString;

@Data
public class LoanApprovalDepartmentBean implements Serializable {
	private int userId;
	private String username;
	@ToString.Exclude
	private String password;
	private String role;
}
