package com.jfsfeb.loanprocessingsystem1.exception;

@SuppressWarnings("serial")
public class LoanException extends RuntimeException {
	public LoanException(String msg) {
		super(msg);
	}

}
