package com.jfsfeb.loanprocessingsystem1.validations;

public interface Validations {
	public boolean validatedName(String name);

	public boolean validatedadminName(String adminName);

	public boolean validatedadminPassword(String adminPassword);

	public boolean validatePassword(String password);

	public boolean validatedRole(String role);

	public boolean validatedId(int id);

	public boolean validatedLoanId(int loanId);

	public boolean validatedPeriod(int period);

	public boolean validateAmount(double id);

	public boolean validateStatus(String status);

	public boolean validatedAadharId(long aadharId);

	public boolean validatedOccupation(String gender);

	public boolean validatedAddress(String name);

	public boolean validateLoanType(String loanType);

	public boolean validatedIntrestRate(float rate);

	public boolean validatedMobile(long mobile);

	public boolean validateEmail(String email);

}
