package com.jfsfeb.loanprocessingsystem1.services;

import java.util.List;

import com.jfsfeb.loanprocessingsystem1.dao.LoanApprovalDepartmentDAO;
import com.jfsfeb.loanprocessingsystem1.dto.LoanApplicationFormBean;
import com.jfsfeb.loanprocessingsystem1.dto.LoansBean;
import com.jfsfeb.loanprocessingsystem1.dto.TrackApplicationBean;
import com.jfsfeb.loanprocessingsystem1.exception.LoanException;
import com.jfsfeb.loanprocessingsystem1.factory.UserFactory;
import com.jfsfeb.loanprocessingsystem1.validations.ValidationsImpl;

public class LoanApprovalDepartmentServicesImpl implements LoanApprovalDepartmentServices {
	LoanApprovalDepartmentDAO dao = UserFactory.getLoanApprovalDepartmentDAOInstance();
	ValidationsImpl val = new ValidationsImpl();

	@Override
	public boolean ladLogin(String username, String password) {
		if (username != null && password != null) {
			if (val.validatedadminName(username)) {
				if (val.validatedadminPassword(password)) {
					return dao.ladLogin(username, password);
				}
			}
		}
		return false;
	}

	@Override
	public List<LoansBean> getAllLoanOffers() {

		return dao.getAllLoanOffers();
	}

	@Override
	public List<LoanApplicationFormBean> getAllApplication() {
		return dao.getAllApplication();
	}

	@Override
	public boolean updateStatus(TrackApplicationBean aStatusBean) {
		if (val.validatedId(aStatusBean.getApplicationFormId())) {
			if (val.validateStatus(aStatusBean.getStatus())) {
				return dao.updateStatus(aStatusBean);
			}
		}
		throw new LoanException("Invalid values");
	}

	@Override
	public List<LoanApplicationFormBean> getApplicationByLoanId(int loanId) {
		if (val.validatedLoanId(loanId)) {

			return dao.getApplicationByLoanId(loanId);
		}

		throw new LoanException("Invalid value..");

	}
}
