package com.jfsfeb.loanprocessingsystem1.validations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.jfsfeb.loanprocessingsystem1.exception.LoanException;

public class ValidationsImpl implements Validations {

	// loan id,application id
		public boolean validatedId(int id) {
			String idRegEx = "[0-9]{1}[0-9]{1}";
			boolean result = false;
			if (Pattern.matches(idRegEx, String.valueOf(id))) {
				result = true;
			} else {
				throw new LoanException("Id should contains exactly 2 digits but not start with 0..");
			}
			return result;
		}

		public boolean validatedPeriod(int period) {
			String idRegEx = "[0-9]{1}[0-9]{1}";
			boolean result = false;
			if (Pattern.matches(idRegEx, String.valueOf(period))) {
				result = true;
			} else {
				throw new LoanException("loan period should contains exactly 2 digits" + " but not start with 0..");
			}
			return result;
		}

		public boolean validateAmount(double id) {
			String idRegEx = "[0-9]{6,7}(\\.[0-9]*)?";
			boolean result = false;
			if (Pattern.matches(idRegEx, String.valueOf(id))) {
				result = true;
			} else {
				throw new LoanException("loan ammount should contains 6-7 digits but not start with 0..");
			}
			return result;
		}

		public boolean validateStatus(String status) {
			String statusRegEx = "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{2,}$";
			boolean result = false;
			Pattern pattern = Pattern.compile(statusRegEx);
			Matcher matcher = pattern.matcher(status);
			if (matcher.matches()) {
				result = true;
			} else {
				throw new LoanException("Application status should  contain  atleast 3 characters "
						+ "and should not contain any digits and special symbols...");
			}
			return result;
		}

		// aadar id
		public boolean validatedAadharId(long aadharId) {
			String idRegEx = "[0-9]{1}[0-9]{11}";
			boolean result = false;

			if (Pattern.matches(idRegEx, String.valueOf(aadharId))) {
				result = true;
			} else {
				throw new LoanException("Aadhar Id should contains exactly 12" + " digits but not start with 0...");
			}
			return result;
		}

		public boolean validatedName(String name) {
			String nameRegEx = "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{2,}$";
			boolean result = false;
			Pattern pattern = Pattern.compile(nameRegEx);
			Matcher matcher = pattern.matcher(name);

			if (matcher.matches()) {
				result = true;
			} else {

				throw new LoanException("Name should  atleast contains 3"
						+ " characters and should not contain digits and special symbols..!");

			}
			return result;

		}

		public boolean validatePassword(String password) {

			String passwordRegEx = "^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[#?!@$%^&*-=()]).{6,}$";
			boolean result = false;
			Pattern pattern = Pattern.compile(passwordRegEx);
			Matcher matcher = pattern.matcher(password);
			if (matcher.matches()) {
				result = true;
			} else {

				throw new LoanException(
						"Enter Valid Passsword with min 6 Characters, " + "One Uppercase and Lowercase and a Symbol");
			}
			return result;
		}

		public boolean validatedOccupation(String gender) {
			String nameRegEx = "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{2,}$";
			boolean result = false;
			Pattern pattern = Pattern.compile(nameRegEx);
			Matcher matcher = pattern.matcher(gender);
			if (matcher.matches()) {
				result = true;
			} else {
				throw new LoanException(
						"Occupation should contain  atleast 3 characters" + " and should not contain digits..!");
			}
			return result;
		}

		public boolean validatedAddress(String name) {
			String nameRegEx = "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{2,}$";
			boolean result = false;
			Pattern pattern = Pattern.compile(nameRegEx);
			Matcher matcher = pattern.matcher(name);
			if (matcher.matches()) {
				result = true;
			} else {
				throw new LoanException("Address should contain  atleast 3 characters"
						+ " and should not contain digits and special symbols..!");
			}
			return result;
		}

		public boolean validatedRole(String role) {
			String nameRegEx = "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{2,}$";
			boolean result = false;
			Pattern pattern = Pattern.compile(nameRegEx);
			Matcher matcher = pattern.matcher(role);
			if (matcher.matches()) {
				result = true;
			} else {
				throw new LoanException("Role should  contain atleast 3 caharcters"
						+ " and should not contain digits and special symbols..!");
			}
			return result;
		}

		public boolean validateLoanType(String loanType) {
			String nameRegEx = "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{2,}$";
			boolean result = false;
			Pattern pattern = Pattern.compile(nameRegEx);
			Matcher matcher = pattern.matcher(loanType);
			if (matcher.matches()) {
				result = true;
			} else {
				throw new LoanException("Loan type should  contain  atleast 3"
						+ " characters and should not contain any digits and special symbols...");
			}
			return result;
		}

		public boolean validatedIntrestRate(float rate) {
			String idRegEx = "[-+]?[0-9]*\\.?[0-9]*";
			boolean result = false;
			if (Pattern.matches(idRegEx, String.valueOf(rate))) {
				result = true;
			} else {
				throw new LoanException("loan intrest rate should have only float values");
			}
			return result;
		}

		public boolean validatedMobile(long mobile) {
			String mobileRegEx = "(0/91)?[6-9][0-9]{9}";
			boolean result = false;
			if (Pattern.matches(mobileRegEx, String.valueOf(mobile))) {
				result = true;
			} else {
				throw new LoanException("Mobile Number  will start with  6 to 9 and It should contains 10 numbers...!");
			}
			return result;
		}

		public boolean validateEmail(String email) {
			String emailRegEx = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
					+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
			boolean result = false;
			Pattern pattern = Pattern.compile(emailRegEx);
			Matcher matcher = pattern.matcher(email);
			if (matcher.matches()) {
				result = true;
			}

			else {
				throw new LoanException("Enter Emailid in proper manner it  contains alphanumeric "
						+ "characters and @ with extension(.com)...!");
			}
			return result;
		}

		@Override
		public boolean validatedadminName(String adminName) {
			String nameRegEx = "^[A-Za-z\\s]{1,}[\\.]{0,1}[A-Za-z\\s]{2,}$";
			boolean result = false;
			Pattern pattern = Pattern.compile(nameRegEx);
			Matcher matcher = pattern.matcher(adminName);

			if (matcher.matches()) {
				result = true;
			} else {

				throw new LoanException("Name should contain atleast 6"
						+ " characters , should not contain digits and should have special symbols..!");

			}
			return result;


		}

		@Override
		public boolean validatedadminPassword(String adminPassword) {
			String passwordRegEx = "^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[#?!@$%^&*-=()]).{6,}$";
			boolean result = false;
			Pattern pattern = Pattern.compile(passwordRegEx);
			Matcher matcher = pattern.matcher(adminPassword);
			if (matcher.matches()) {
				result = true;
			} else {

				throw new LoanException(
						"Enter Valid Passsword with min 6 Characters, " + "One Uppercase and Lowercase and a Symbol");
			}
			return result;

		}

		@Override
		public boolean validatedLoanId(int loanId) {
			String idRegEx = "[0-9]{1}[0-9]{1}";
			boolean result = false;
			if (Pattern.matches(idRegEx, String.valueOf(loanId))) {
				result = true;
			} else {
				throw new LoanException("Id should contains exactly 2 digits but not start with 0..");
			}
			return result;
		}


}
