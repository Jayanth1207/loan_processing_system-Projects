package com.jfsfeb.loanprocessingsystem1.services;

import java.util.List;

import com.jfsfeb.loanprocessingsystem1.dto.LoanApplicationFormBean;
import com.jfsfeb.loanprocessingsystem1.dto.LoanApprovalDepartmentBean;
import com.jfsfeb.loanprocessingsystem1.dto.LoansBean;
import com.jfsfeb.loanprocessingsystem1.dto.TrackApplicationBean;

public interface LoanApprovalDepartmentServices {

	public boolean ladLogin(String username, String password);

	public List<LoansBean> getAllLoanOffers();

	public List<LoanApplicationFormBean> getAllApplication();// view

	public boolean updateStatus(TrackApplicationBean aStatusBean);

	public List<LoanApplicationFormBean> getApplicationByLoanId(int loanId);
}
